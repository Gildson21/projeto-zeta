-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 11/04/2017 às 18:31
-- Versão do servidor: 5.7.14
-- Versão do PHP: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `celke`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `categoria`
--

CREATE TABLE `categoria` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `categoria`
--

INSERT INTO `categoria` (`id`, `nome`, `created`, `modified`) VALUES
(1, 'Viagens, Pousadas e VeÃ­culos', '2017-02-15 20:17:12', NULL),
(2, 'Ãgua, Alimentos e Bebidas', '2017-02-15 20:17:28', NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `empresa`
--

CREATE TABLE `empresa` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `segmento` varchar(255) NOT NULL,
  `endereco` varchar(255) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `fone1` varchar(20) NOT NULL,
  `fone2` varchar(20) NOT NULL,
  `fone3` varchar(20) NOT NULL,
  `email` varchar(220) NOT NULL,
  `site` varchar(50) NOT NULL,
  `imagem` varchar(255) NOT NULL,
  `situacao_id` int(11) NOT NULL,
  `categoria_id` int(11) NOT NULL,
  `subcategoria_id` int(11) NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `empresa`
--

INSERT INTO `empresa` (`id`, `nome`, `segmento`, `endereco`, `telefone`, `fone1`, `fone2`, `fone3`, `email`, `site`, `imagem`, `situacao_id`, `categoria_id`, `subcategoria_id`, `modified`, `created`) VALUES
(2, 'CA Lanches', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 1, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(3, 'DR Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(7, 'Meu Lanches Companhia', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 1, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(8, 'Roder Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(9, 'Distribuidora gronder', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 2, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(10, 'Alugel fÃ¡cil - Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(11, 'Sim Lanches', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 1, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(12, 'CM Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(13, '2CA Lanches', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 1, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(14, '2DR Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(15, '2Meu Lanches Companhia', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 1, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(16, '2Roder Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(17, '2Distribuidora gronder', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 2, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(18, '2Alugel fÃ¡cil - Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(20, '2CM Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(21, 'CA Lanches', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 1, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(22, 'DR Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(23, 'Meu Lanches Companhia', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 1, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(24, 'Roder Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(25, 'Distribuidora gronder', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 2, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(26, 'Alugel fÃ¡cil - Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(27, 'Sim Lanches', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 1, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(28, 'CM Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(29, '2CA Lanches', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 1, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(30, '2DR Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(31, '2Meu Lanches Companhia', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 1, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(32, '2Roder Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(33, '2Distribuidora gronder', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 2, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(34, '2Alugel fÃ¡cil - Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(35, '2CM Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(36, 'CA Lanches', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 1, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(37, 'DR Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(38, 'Meu Lanches Companhia', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 1, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(39, 'Roder Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(40, 'Distribuidora gronder', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 2, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(41, 'Alugel fÃ¡cil - Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(42, 'Sim Lanches', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 1, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(43, 'CM Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(44, '2CA Lanches', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 1, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(45, '2DR Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(46, '2Meu Lanches Companhia', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 1, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(47, '2Roder Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(48, '2Distribuidora gronder', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 2, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(49, '2Alugel fÃ¡cil - Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(50, '2CM Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(51, 'CA Lanches', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 1, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(52, 'DR Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(53, 'Meu Lanches Companhia', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 1, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(54, 'Roder Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(55, 'Distribuidora gronder', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 2, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(56, 'Alugel fÃ¡cil - Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(57, 'Sim Lanches', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 1, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(58, 'CM Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(59, '2CA Lanches', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 1, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(60, '2DR Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(61, '2Meu Lanches Companhia', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 1, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(62, '2Roder Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(63, '2Distribuidora gronder', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 2, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(64, '2Alugel fÃ¡cil - Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(65, '2CM Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(66, 'CA Lanches', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 1, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(67, 'DR Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(68, 'Meu Lanches Companhia', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 1, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(69, 'Roder Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(70, 'Distribuidora gronder', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 2, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(71, 'Alugel fÃ¡cil - Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(72, 'Sim Lanches', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 1, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(73, 'CM Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(74, '2CA Lanches', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 1, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(75, '2DR Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(76, '2Meu Lanches Companhia', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 1, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(77, '2Roder Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(78, '2Distribuidora gronder', 'Lanche em Geral', 'rua juviano', '33611158', '88834858', '8883485896', '888348985', 'fia@gmail.com', 'livraria.com.br', 'slide6.jpg', 1, 2, 2, '2017-02-04 22:55:39', '2017-02-03 00:00:00'),
(79, '2Alugel fÃ¡cil - Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16'),
(80, '2CM Aluguel carro', 'Aluguel', 'Rua Elisio Curvelo', '83336584', '83987564532', '8333611137', '83987653421', 'salao@gmail.com', 'salao.com.br', '', 1, 1, 3, NULL, '2017-02-04 21:58:16');

-- --------------------------------------------------------

--
-- Estrutura para tabela `subcategoria`
--

CREATE TABLE `subcategoria` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `categoria_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `subcategoria`
--

INSERT INTO `subcategoria` (`id`, `nome`, `categoria_id`, `created`, `modified`) VALUES
(1, 'BARES', 2, '2017-02-15 23:54:01', NULL),
(2, 'AGUA E GELO\n', 2, '2017-02-15 23:54:27', NULL),
(3, 'CARROS', 1, '2017-02-15 23:54:54', NULL);

--
-- Índices de tabelas apagadas
--

--
-- Índices de tabela `categoria`
--
ALTER TABLE `categoria`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `empresa`
--
ALTER TABLE `empresa`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `subcategoria`
--
ALTER TABLE `subcategoria`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas apagadas
--

--
-- AUTO_INCREMENT de tabela `categoria`
--
ALTER TABLE `categoria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT de tabela `empresa`
--
ALTER TABLE `empresa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;
--
-- AUTO_INCREMENT de tabela `subcategoria`
--
ALTER TABLE `subcategoria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=147;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
